/**
 * Resources folder with TestNG XML and SuiteRunnerClass
 * @author ritvikkhare
 *
 */
package test.java.frm.resources;