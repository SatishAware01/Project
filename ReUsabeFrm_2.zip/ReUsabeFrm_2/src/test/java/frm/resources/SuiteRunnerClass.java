package test.java.frm.resources;

import java.util.Date;
import java.util.List;

import org.testng.TestNG;
import org.testng.collections.Lists;
/**
 * Class to run TestNG xml suite for Sequence and Parallel
 * @author ritvikkhare
 *
 */
public class SuiteRunnerClass {

	public static void main(String[] args){
	    TestNG testng = new TestNG();
	    List<String> suites = Lists.newArrayList();
	    //suites.add(".//src//test/java//frm//resources//SequenceTest.xml");
	    suites.add(".//src//test/java//frm//resources//ParallelTest1.xml");
	    testng.setTestSuites(suites);
	    //testng.setOutputDirectory("/Users/ritvikkhare/Documents/workspace/junksfolder/TestNG");//MAC PATHs
	    testng.setOutputDirectory("C:/Users/ritvik.khare/Desktop/Reports/TestNG");
	    Date start=new Date();
	    System.out.println("Starts at " + start.toString().replace(":", "_").replace(" ", "_"));
	    testng.run();
	    Date end=new Date();
	    System.out.println("End at " + end.toString().replace(":", "_").replace(" ", "_"));

	    System.out.println("Total time Taken = " + (end.getTime()-start.getTime()));
	}

}
