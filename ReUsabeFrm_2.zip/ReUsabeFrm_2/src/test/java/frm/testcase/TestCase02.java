package test.java.frm.testcase;

import java.util.Hashtable;

import org.openqa.selenium.support.PageFactory;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import main.java.frm.pages.F00_LaunchHomePg;
import main.java.frm.pages.F01_Page01;
import main.java.frm.pages.F02_Page02;
import main.java.frm.util.DataUtil;
import main.java.frm.util.FrmConstants;
import test.java.frm.testcase.base.BaseTest;

/**
 * TestCase02 Class, TestNG Class can be run independently.
 * @author ritvikkhare
 *
 */
public class TestCase02 extends BaseTest{

	String testCaseName="Test002";

	/**
	 * Test Case 02, contains the functions calls of function library.
	 *
	 * @param htData  Hash table for the Test Case
	 */
	@Test(dataProvider="testcase02Data")
	public void testCase02(Hashtable <String,String> htData)
	{
		testRowResult = new Hashtable<Integer,String>();
		test = extent.startTest(htData.get("ROWID"), htData.get("ROWID") + " Result");

		testRowResult.put(FrmConstants.EXCEL_TESTROWID, htData.get("ROWID"));
		if(!DataUtil.isTestExecutable(xls, testCaseName) ||  htData.get(FrmConstants.RUNMODE_COL).equals("N")){
			test.log(LogStatus.SKIP, "Skipping the test as Rnumode is N");
			testRowResult.put(FrmConstants.EXCEL_STATUS, "Skip");
			testRowResult.put(FrmConstants.EXCEL_COMMENTS, "Runmode N in Datasheet");
			throw new SkipException("Skipping the test as Rnumode is N");
		}
		///Test Case

		test.log(LogStatus.INFO, "1st Line in Report.");

		initb(htData.get("Browser"));

		F00_LaunchHomePg objlaunchPg= new F00_LaunchHomePg(driver,test,apDetails);
		PageFactory.initElements(driver, objlaunchPg);

		F01_Page01 objF01=objlaunchPg.launchHomePg();
		objF01.verifyTitle("SampleTitle");

		String stNextPage="JavaScript";
		Object objtemp=objF01.goToNextPage(stNextPage);

		if (objtemp instanceof F02_Page02)
		{
			//Pass, go to next
			F02_Page02 objPg2 =(F02_Page02) objtemp;
			objPg2.verifyJavaScriptPageLoad();
			objPg2.getHeaderSection().performHeaderAction();
		}
		else
		{
			reportFailure("Go to Javascript Page Failed");
			//report failure
		}
		testRowResult.put(FrmConstants.EXCEL_STATUS, "Pass");
		testRowResult.put(FrmConstants.EXCEL_COMMENTS, htData.get("ROWID"));
	}

	@AfterMethod
	public void quitTest()
	{
		summaryReport.put(icntExecutionRow++, testRowResult);
		if(extent!=null)
		{
		extent.endTest(test);
		extent.flush();
		}

		if(driver!=null)
			driver.quit();
	}


	@AfterClass
	public void afterClass()
	{
		htExcelMasterReport.put(2, summaryReport);
	}

	@DataProvider
	public Object[][] testcase02Data()
	{
		return DataUtil.getData(xls, testCaseName);
	}
}
