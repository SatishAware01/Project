package test.java.frm.testcase.base;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import main.java.frm.util.Application_Details;
import main.java.frm.util.ExcelReport;
import main.java.frm.util.ExtentManager;
import main.java.frm.util.FrmConstants;
import main.java.frm.util.XL_ReadWrite;

public class BaseTest {

	public ExtentReports extent = ExtentManager.getInstance();
	public ExtentTest test;
	
	/**
	 * XLS object for Data.xlsx
	 */
	public static XL_ReadWrite xls = new XL_ReadWrite(FrmConstants.DATA_XLS_PATH);
	public Hashtable<Integer,Hashtable<Integer,String>> summaryReport=ExcelReport.getReportInstance();
	public static Hashtable<Integer,Hashtable<Integer,Hashtable<Integer,String>>> htExcelMasterReport = new Hashtable<Integer,Hashtable<Integer,Hashtable<Integer,String>>>();
	public Hashtable<Integer,String> testRowResult;
	public WebDriver driver;
	public Application_Details apDetails=new Application_Details();
	public static int icntExecutionRow=0;
	public void initb(String bType)
	{
		if(!FrmConstants.GRID_RUN){
			// local machine
			if(bType.equals("Mozilla"))
				driver= new FirefoxDriver();
			else if(bType.equals("Chrome")){
				System.setProperty("webdriver.chrome.driver", FrmConstants.stCHORMEDRIVER);
				driver= new ChromeDriver();
			}
		}else{
			// grid
			DesiredCapabilities cap=null;
			if(bType.equals("Mozilla")){
				cap = DesiredCapabilities.firefox();
				cap.setBrowserName("firefox");
				cap.setJavascriptEnabled(true);
				cap.setPlatform(org.openqa.selenium.Platform.WINDOWS);

			}else if(bType.equals("Chrome")){
				 cap = DesiredCapabilities.chrome();
				 cap.setBrowserName("chrome");
				 cap.setPlatform(org.openqa.selenium.Platform.MAC);
			}

			try {
				driver = new RemoteWebDriver(new URL("http://191.168.0.1:4444/grid/hub/"), cap);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	public void takeScreenShot(){
		Date d=new Date();
		String screenshotFile=d.toString().replace(":", "_").replace(" ", "_")+".png";
		String filePath=FrmConstants.REPORTS_PATH+"screenshots//"+screenshotFile;
		// store screenshot in that file
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			System.out.println("Base Test : Take Screenshot error.");
			e.printStackTrace();
		}
		test.log(LogStatus.INFO,test.addScreenCapture(filePath));
	}

	public void reportFailure(String failureMessage){
		test.log(LogStatus.FAIL, failureMessage);
		testRowResult.put(FrmConstants.EXCEL_STATUS, "FAIL");
		testRowResult.put(FrmConstants.EXCEL_COMMENTS, failureMessage);
		takeScreenShot();
		Assert.fail(failureMessage);
	}


}
