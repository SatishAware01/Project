package main.java.frm.util;

/**
 * Framework Constants Class.
 * Drivers path, report paths, data sheet, etc.
 * @author ritvikkhare
 *
 */
public class FrmConstants {

	//paths for drivers, data, config
	public static final boolean GRID_RUN = false;
	public static final String stCHORMEDRIVER="C:/jba/workspaces/Drivers/chromedriver_win32_v3.6/chromedriver.exe";
	public static final String stIEDRIVER="";

	public static final String DATA_XLS_PATH = System.getProperty("user.dir") + "/frm_config/data/Data.xlsx";
	public static final String APPDETAILS_XLS_PATH = System.getProperty("user.dir") + "/frm_config/data/ENV_ObjectRepository.xlsx";
	public static final String REPORTS_PATH = "C:/Users/ritvik.khare/Desktop/Reports/";
	public static final String TEST_XLS_PATH = System.getProperty("user.dir") + "/frm_config/data/Testcompare.xlsx";
	//Environment and Configuration
	public static final String stENVIRONMENT="INT";

	/**
	 * TODO : Should have constants for the Excel Report Columns
	 */

	public static final String TESTCASES_SHEET="TestCases";
	public static final String TESTDATA_SHEET="TestData";
	public static final String RUNMODE_COL="Runmode";

	public static final String ENVDETAILS_SHEET="ENVDetails";
	public static final String OBJECTREPO_SHEET="ObjectRepository";

	public static final Integer EXCEL_TESTROWID=1;
	public static final Integer EXCEL_STATUS=2;
	public static final Integer EXCEL_COMMENTS=3;


}