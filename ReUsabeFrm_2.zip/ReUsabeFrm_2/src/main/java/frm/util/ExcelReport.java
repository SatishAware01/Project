package main.java.frm.util;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Hashtable;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Class for Reporting through Excel.
 * Have Master HashTable for collecting child reports from test cases
 * @author Ritvik Khare
 * @version 1.0
 * TODO : Needs to extend to Other reporting formats.
 */
public class ExcelReport {

	private static Hashtable<Integer,Hashtable<Integer,String>> htreportMaster;

	/**
	 * Function to return single instance of Excel Report Master
	 * @return Report Master Instance.
	 */
	public static Hashtable<Integer,Hashtable<Integer,String>> getReportInstance() {
		if (htreportMaster == null) {
				htreportMaster = new Hashtable<Integer,Hashtable<Integer,String>>();
		}
		return htreportMaster;
	}

	/**
	 * To create an Excel with the Data stored in Report Hash table
	 * Also populate the Summary Sheet with the details
	 * @param htExcelMasterReport report excel master to be populated in Excel
	 */
	public static void populateExcel_reportMaster(Hashtable<Integer,Hashtable<Integer,Hashtable<Integer,String>>> htExcelMasterReport)
	{
		Date d=new Date();
		String fileName=d.toString().replace(":", "_").replace(" ", "_")+".xlsx";
		String reportPath =FrmConstants.REPORTS_PATH+fileName;
		System.out.println("Report is at location with name : " + reportPath);

		XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("ExcelReport");

        for(int icntWorksheet=1;icntWorksheet<=htExcelMasterReport.size();icntWorksheet++)
        {
        		Row row;
        		for (int icntRow=0;icntRow<htExcelMasterReport.get(icntWorksheet).size();icntRow++)
        		{
        			row = sheet.createRow(icntRow);
        			for(int icntCol=0;icntCol<=htExcelMasterReport.get(icntWorksheet).get(icntRow).size();icntCol++ )
        			{
        				Cell cell = row.createCell(icntCol);
        				if(htExcelMasterReport.get(icntWorksheet).get(icntRow).get(icntCol)!=null)
        	                cell.setCellValue((String)htExcelMasterReport.get(icntWorksheet).get(icntRow).get(icntCol));
        				else
        					cell.setCellValue("");

        			}
        		}
         }


        try (FileOutputStream outputStream = new FileOutputStream(reportPath)) {
            workbook.write(outputStream);
        }catch(Exception ex)
        {
        	System.out.println("ExcelReport.java || Error in writing Excel :" + ex.getMessage());
        }
        try {
			workbook.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


    /*
    Object[][] bookData = {
            {"Head First Java", "Kathy Serria", 79},
            {"Effective Java", "Joshua Bloch", 36},
            {"Clean Code", "Robert martin", 42},
            {"Thinking in Java", "Bruce Eckel", 35},
    };


    int rowCount = 0;

    for (Object[] aBook : bookData) {
        Row row = sheet.createRow(++rowCount);

        int columnCount = 0;

        for (Object field : aBook) {
            Cell cell = row.createCell(++columnCount);
            if (field instanceof String) {
                cell.setCellValue((String) field);
            } else if (field instanceof Integer) {
                cell.setCellValue((Integer) field);
            }
        }
    }
     */

	/**
	 * Dummy report Data to check code.
	 * @return hasHtable with dummy data
	 */
	public static Hashtable<Integer,Hashtable<Integer,Hashtable<Integer,String>>> getSample()
	{
		Hashtable<Integer,String> htrows = new Hashtable<Integer,String>();

		htrows.put(0, "Col1");
		htrows.put(1, "Col2");
		htrows.put(2, "Col3");

		Hashtable<Integer,String> htrows2 = new Hashtable<Integer,String>();

		htrows2.put(0, "abcde");
		htrows2.put(1, "cde");
		htrows2.put(2, "abe");

		Hashtable<Integer,String> htrows3 = new Hashtable<Integer,String>();

		htrows3.put(0, "abcde");
		htrows3.put(1, "cde");
		htrows3.put(2, "abe");

		Hashtable<Integer,Hashtable<Integer,String>> htWorksheet = new Hashtable<Integer,Hashtable<Integer,String>>();

		htWorksheet.put(0,htrows);
		htWorksheet.put(1,htrows2);
		htWorksheet.put(2,htrows3);

		Hashtable<Integer,Hashtable<Integer,Hashtable<Integer,String>>> htMaster= new Hashtable<Integer,Hashtable<Integer,Hashtable<Integer,String>>>();

		htMaster.put(0, htWorksheet);
		htMaster.put(1, htWorksheet);
		return htMaster;
	}

	/*public static void main(String[] args){
		populateExcel_reportMaster(getSample());
	}*/
}

