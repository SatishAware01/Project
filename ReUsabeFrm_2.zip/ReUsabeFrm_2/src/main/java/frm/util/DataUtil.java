package main.java.frm.util;

import java.util.Hashtable;

/**
 * Read Data for the Test Methods in Test Classes.
 * @author ritvikkhare
 *
 */
public class DataUtil {

	/**
	 * Function to read the data sheet for specific TestCase into a HashTable
	 * @param xls XL Object
	 * @param testCaseName TestCase Name for the data hash table.
	 * @return data HashTable String,HashTable String,String
	 */
	public static Object[][] getData(XL_ReadWrite xls, String testCaseName){
		try{
	    String sheetName=FrmConstants.TESTDATA_SHEET;
		// reads data for only testCaseName

		int testStartRowNum=1;
		while(!xls.getCellData(sheetName, 0, testStartRowNum).equals(testCaseName)){
			testStartRowNum++;
		}
		System.out.println(testCaseName + " | Row Start at- "+ testStartRowNum);
		int colStartRowNum=testStartRowNum+1;
		int dataStartRowNum=testStartRowNum+2;

		// calculate rows of data
		int rows=0;
		while(!xls.getCellData(sheetName, 0, dataStartRowNum+rows).equals("")){
			rows++;
		}
		System.out.println(testCaseName + " | Total rows are  - "+rows );

		//calculate total cols
		int cols=0;
		while(!xls.getCellData(sheetName, cols, colStartRowNum).equals("")){
			cols++;
		}
		System.out.println(testCaseName + " | Total cols are  - "+cols );
		Object[][] data = new Object[rows][1];
		//read the data
		int dataRow=0;
		Hashtable<String,String> table=null;
		for(int rNum=dataStartRowNum;rNum<dataStartRowNum+rows;rNum++){
			table = new Hashtable<String,String>();
			for(int cNum=0;cNum<cols;cNum++){
				String key=xls.getCellData(sheetName,cNum,colStartRowNum);
				String value= xls.getCellData(sheetName, cNum, rNum);
				table.put(key, value);
				// 0,0 0,1 0,2
				//1,0 1,1
			}
			data[dataRow][0] =table;
			dataRow++;
		}
		return data;
		}
		catch(Exception ex)
		{
		    ex.printStackTrace();
		}
		return null;
	}

	/**
	 * Read Excel WorkSheet into a HashTable with Integer Key and HashTable String , String Value
	 * @param xls : Excel Object
	 * @param testCaseName : Test Case Name
	 * @return HashTable Integer , HashTable String , String
	 */
	public static Hashtable <Integer,Hashtable <String,String>> getDataHashtable(XL_ReadWrite xls, String testCaseName){
		Hashtable <Integer,Hashtable <String,String>> htReturn=new Hashtable <Integer,Hashtable <String,String>>();
		String sheetName=FrmConstants.TESTDATA_SHEET;
		// reads data for only testCaseName

		int testStartRowNum=1;
		while(!xls.getCellData(sheetName, 0, testStartRowNum).equals(testCaseName)){
			testStartRowNum++;
		}
		System.out.println("Test Data Starts at : " + xls.getCellData(sheetName, 0, (testStartRowNum)));
		System.out.println("Test starts from row - "+ testStartRowNum);
		int colStartRowNum=testStartRowNum+1;
		int dataStartRowNum=testStartRowNum+2;

		// calculate rows of data
		int rows=0;
		while(!xls.getCellData(sheetName, 0, dataStartRowNum+rows).equals("")){
			rows++;
		}
		System.out.println("Total rows are  - "+rows );

		//calculate total cols
		int cols=0;
		while(!xls.getCellData(sheetName, cols, colStartRowNum).equals("")){
			cols++;
		}
		System.out.println("Total cols are  - "+cols );

		//read the data
		int dataRow=0;
		Hashtable<String,String> table=null;
		for(int rNum=dataStartRowNum;rNum<dataStartRowNum+rows;rNum++){
			table = new Hashtable<String,String>();
			for(int cNum=0;cNum<cols;cNum++){
				String key=xls.getCellData(sheetName,cNum,colStartRowNum);
				String value= xls.getCellData(sheetName, cNum, rNum);
				table.put(key, value);
				// 0,0 0,1 0,2
				//1,0 1,1
			}
			htReturn.put(dataRow,table);
			dataRow++;
		}
		return htReturn;
	}


	/**
	 * To check if TestCase is RunMode Y/N
	 * @param xls XL_ReadWrite object to be passed.
	 * @param testCaseName to be passed to get the Executable
	 * @return true if Y, false if N
	 */
	public static boolean isTestExecutable(XL_ReadWrite xls, String testCaseName){
		int rows = xls.getRowCount(FrmConstants.TESTCASES_SHEET);
		for(int rNum=2;rNum<=rows;rNum++){
			String tcid = xls.getCellData(FrmConstants.TESTCASES_SHEET, "TCID", rNum);
			if(tcid.equals(testCaseName)){
				String runmode = xls.getCellData(FrmConstants.TESTCASES_SHEET, "Runmode", rNum);
				if(runmode.equals("Y"))
					return true;
				else
					return false;

			}
		}
		return false;
	}
}
