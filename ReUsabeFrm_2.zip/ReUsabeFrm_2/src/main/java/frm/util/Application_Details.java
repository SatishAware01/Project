/**
 * Utility package that contains Framework re usable components.
 */
package main.java.frm.util;

import java.util.Hashtable;

/**
 * Class to read Environment and configuration Details from ENV_ObjectRepository sheet
 * Environment, Object Repository
 * @author ritvikkhare
 *
 */
public class Application_Details {


	
	XL_ReadWrite xlfileRead;
	public static Hashtable<String,Hashtable<String,Hashtable<String,String>>> htAppDetails;
	
	/**
	 * Initializing local xlFileRead object
	 */
	public Application_Details()
	{
		xlfileRead = new XL_ReadWrite(FrmConstants.APPDETAILS_XLS_PATH);
		if(htAppDetails==null)
		ReadXLtoHashtable();
	}
	
	/**
	 * Function to read excel to HashTable 
	 */
	void ReadXLtoHashtable()
	{
		/*
		 *Read each cell data of a row with key as column
		 *for all such HashTable save  
		 *Read each WorkSheet in a separate HashTable
		 * */

		String[] sheetNameList= {FrmConstants.ENVDETAILS_SHEET,FrmConstants.OBJECTREPO_SHEET};
		Hashtable<String,String> htColValueHash;
		Hashtable<String,Hashtable<String,String>> htRowIDHashtable = new Hashtable<String,Hashtable<String,String>>();
		htAppDetails=new Hashtable<String,Hashtable<String,Hashtable<String,String>>>();
		for (String sheetName :sheetNameList)
		{
			//Get total rows and total columns
			htRowIDHashtable = new Hashtable<String,Hashtable<String,String>>();
			for(int icntrw=2;icntrw<=xlfileRead.getRowCount(sheetName);icntrw++)
			{
				htColValueHash=new Hashtable<String, String>();
				// for each row
				for(int icntcol=0; icntcol<=xlfileRead.getColumnCount(sheetName);icntcol++)
				{ // for each column
					String stCol=xlfileRead.getCellData(sheetName, icntcol, 1);
					if(!stCol.isEmpty())
					{
						String stVal=xlfileRead.getCellData(sheetName, icntcol, icntrw);
						if(!stVal.isEmpty()) // if Val is empty
							htColValueHash.put(stCol, stVal);
						else
							htColValueHash.put(stCol, "");
					}
				}
				htRowIDHashtable.put(xlfileRead.getCellData(sheetName, 0 , icntrw), htColValueHash);				
			}
			htAppDetails.put(sheetName,htRowIDHashtable);
		}
	}
	
	/**
	 * To get value from the HashTable of Application Details
	 * @param sheetName : SheetName
	 * @param colNameKey : Key to Identify the Row
	 * @param rowIDValueReturn : Column name to get value.
	 * @return : Value of the cell, if there is an exception it will return ""
	 */
	public String getCellValue(String sheetName,String colNameKey,String rowIDValueReturn)
	{
		try{
		return htAppDetails.get(sheetName).get(colNameKey).get(rowIDValueReturn);
		}
		catch(Exception ex)
		{
			System.out.println("Application_Details : getCellValue Exception in reading the data of the column");
			return "";
		}
	}

	
	/*public static void main(String[] srgs)
	{
		Application_Details objTest=new Application_Details();
		System.out.println(objTest.getCellValue(FrmConstants.ENVDETAILS_SHEET, "QA", "URL"));
	}*/

}
