package main.java.frm.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

/**
 * Class to Perform Actions on Excel WorkSheet
 * Comparisons, Duplicates, Unique rows etc.
 * @author ritvikkhare
 *
 */
public class ExcelOperations {

	/**
	 * Compare two rows on basis of columns defined in a list.
	 * After comparison, identify unique rows
	 */

    /**
     * Test Data row start with
     */
	int iRowID=2;
	/**
	 * XL object to perform action upon.
	 */
	XL_ReadWrite xlObj;

	/**
	 * Initialize the object of Data Sheet.
	 * @param path : Path of the Excel Data Sheet
	 */
	public ExcelOperations(String path) {
	    xlObj=new XL_ReadWrite(path);
	}

	/**
	 * List common rows of the test cases in the given work sheet.
	 * Based on the List of columns to consider a unique combination.
	 * @param stDataSheet : WorkSheet Name
	 * @param colToCompare : Columns in scope for Comparison as common.
	 * @param testCaseName : list of Tests Group to check.
	 */
    public void listCommonTDRsforTestCase(String stDataSheet, String[] colToCompare, String[] testCaseName)
	{
            for(int iTestCaseNameCnt=0;iTestCaseNameCnt<testCaseName.length;iTestCaseNameCnt++)
            {
                int testStartRowNum=1;
                while(!xlObj.getCellData(stDataSheet, 0, testStartRowNum).equals(testCaseName[iTestCaseNameCnt])){
                    testStartRowNum++;
                }

                System.out.println("Test Data Starts at : " + xlObj.getCellData(stDataSheet, 0,testStartRowNum));
                System.out.println("Test starts from row - "+ testStartRowNum);
                int colStartRowNum=testStartRowNum+1;
                int dataStartRowNum=testStartRowNum+2;

                //calculate rows of data
                int rows=0;
                while(!xlObj.getCellData(stDataSheet, 0, dataStartRowNum+rows).equals("")){
                    rows++;
                }
                System.out.println("Total rows are  - "+rows );

                //calculate total cols
                int cols=0;
                while(!xlObj.getCellData(stDataSheet, cols, colStartRowNum).equals("")){
                    cols++;
                }

                int[] colNumbers= getColumnNumbers(colToCompare,stDataSheet,colStartRowNum,cols);

                //read the data
                int iconCateRow=0;
                ArrayList<String> lstArr = new ArrayList<>();
                String[][] stArr = new String[rows][2];//[RowID,Concatenated Text][]
                for(int rNum=dataStartRowNum;rNum<dataStartRowNum+rows;rNum++){
	            stArr[iconCateRow][0]=xlObj.getCellData(stDataSheet, iRowID , rNum);
                for (int icntCol=0;icntCol<colNumbers.length;icntCol++)
                {
                    if(stArr[iconCateRow][1]==null)
                        stArr[iconCateRow][1]="";
                    stArr[iconCateRow][1]=stArr[iconCateRow][1]+xlObj.getCellData(stDataSheet,colNumbers[icntCol], rNum)+ "##";
                }
                lstArr.add(stArr[iconCateRow][1]);
                iconCateRow++;
	        }
                displayListofDuplicate( duplicateList(lstArr,stArr));
            }
	}

    /**
     * Get the array list of column numbers of the array for columns to compare.
     * @param colToCompare : List of columns.
     * @param stDataSheet : Work Sheet name.
     * @param colStartRowNum : Starting row for columns.
     * @param cols : Total number of columns.
     * @return : Integer array of column numbers.
     */
    public int[] getColumnNumbers(String[] colToCompare,String stDataSheet, int colStartRowNum,  int cols)
    {
        int[] colNumbers= new int[colToCompare.length];
        int icol=0;
        for (String col : colToCompare)
        {
            for(int icntCol=0;icntCol<cols;icntCol++)
            {
                if(xlObj.getCellData(stDataSheet, icntCol, colStartRowNum).equals(col))
                {
                    colNumbers[icol]=icntCol;
                    icol++;
                    break;
                }
            }

        }
        return colNumbers;
    }

    /**
     * Print the list of duplicate on Console.
     * @param stArr : HashSet list of common sets of rows.
     */
    public void displayListofDuplicate(HashSet<String> stArr)
    {
        int iSet=1;
        for(String stVal : stArr)
        {
            if((stVal.length()!=0))
            System.out.println("Common Rows Set = "+ iSet++ + " [" + stVal.substring(0, stVal.length()-4) + "]");

        }
    }

    /**
     * Identify duplicate rows in the TDRs for given list of columns.
     * @param stUnique : List of Unique Rows Data.
     * @param stArr : Total List of Rows Data.
     * @return : List of common groups of TDRs.
     */
    public HashSet<String> duplicateList(ArrayList<String> stUnique,String[][] stArr)
    {
        String[] stDuplicate=new String[stUnique.size()]; //unique set to duplicate
        int iDuplicate=0;
        boolean commonFlag;
        int iMoreThanTwo;
        for (String unSt : stUnique)
        {   iMoreThanTwo=1;

            stDuplicate[iDuplicate]="";

            for (int rNum=0;rNum<(stArr.length);rNum++)
            { commonFlag=false;
                if(stArr[rNum][1].equalsIgnoreCase(unSt))
                {
                    iMoreThanTwo++;
                    commonFlag=true;
                }
                if(iMoreThanTwo>1 && commonFlag)
                {
                    stDuplicate[iDuplicate]=stDuplicate[iDuplicate] + stArr[rNum][0] + " || ";
                }
                if(iMoreThanTwo==2 && rNum==(stArr.length-1))
                {
                    stDuplicate[iDuplicate]="";
                }
            }
            iDuplicate++;
        }

        return new HashSet<>(Arrays.asList(stDuplicate));
    }

	public static void main(String[] a)
	{
		ExcelOperations ob= new ExcelOperations(FrmConstants.TEST_XLS_PATH);
		ob.listCommonTDRsforTestCase(FrmConstants.TESTDATA_SHEET, new String[]{"LNK_DataCol","LNK_DataCol2"},new String[]{"Test001","Test002"});

	}
}
