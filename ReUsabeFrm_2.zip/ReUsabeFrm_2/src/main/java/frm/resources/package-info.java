/**
 * resources Package for storing XML, configuration files.
 * @author ritvikkhare
 *
 */
package main.java.frm.resources;