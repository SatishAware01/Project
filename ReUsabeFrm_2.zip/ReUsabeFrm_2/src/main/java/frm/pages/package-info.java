/**
 * Collection of Page Object Model Classes for each page.
 * @author ritvikkhare
 *
 */
package main.java.frm.pages;