package main.java.frm.pages;

import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import main.java.frm.pages.base.BasePage;
import main.java.frm.util.Application_Details;

public class F02_Page02 extends BasePage{

	
	public F02_Page02(WebDriver driver,ExtentTest test,Application_Details appDetails)
	{
		super(driver,test,appDetails);	
	}
	
	public void verifyJavaScriptPageLoad()
	{
		// Verify Java is loaded.
	}

}
