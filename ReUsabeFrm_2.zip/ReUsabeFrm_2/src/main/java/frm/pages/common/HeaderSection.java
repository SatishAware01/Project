package main.java.frm.pages.common;

import org.openqa.selenium.WebDriver;

public class HeaderSection {

	WebDriver webD;
	public HeaderSection(WebDriver driver)
	{
		this.webD=driver;
	}
	
	public void performHeaderAction()
	{
		//any action related to Header
	}
}
