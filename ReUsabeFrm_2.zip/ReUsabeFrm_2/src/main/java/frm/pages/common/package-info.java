/**
 * Package for Header and Footer Section
 * @author ritvikkhare
 *
 */
package main.java.frm.pages.common;