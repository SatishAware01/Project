package main.java.frm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;

import main.java.frm.pages.base.BasePage;
import main.java.frm.util.Application_Details;
import main.java.frm.util.FrmConstants;

/**
 * Page Object Model Class for Performing the first Action : Launch the URL as per Configuration in Data
 * @author ritvikkhare
 *
 */
public class F00_LaunchHomePg extends BasePage{

	
	public F00_LaunchHomePg(WebDriver driver,ExtentTest test,Application_Details appDetails)
	{
		super(driver,test,appDetails);	
	}
	
	/**
	 * Function to load the URL to land on first page(index.HTML)
	 * @return Object of Following 1st Page of application/Landing Page.
	 */
	public F01_Page01 launchHomePg()
	{	
		webD.get(apDetails.getCellValue(FrmConstants.ENVDETAILS_SHEET, FrmConstants.stENVIRONMENT,"URL"));
		F01_Page01 objPage1= new F01_Page01(webD,test,apDetails);
		PageFactory.initElements(webD, objPage1);
		return objPage1;

	}
	
}
