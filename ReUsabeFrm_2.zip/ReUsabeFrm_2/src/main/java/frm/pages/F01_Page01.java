package main.java.frm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import main.java.frm.pages.base.BasePage;
import main.java.frm.util.Application_Details;
import main.java.frm.util.FrmConstants;

/**
 * Page Object Model Class for First Page in the application
 * @author ritvikkhare
 *
 */
public class F01_Page01 extends BasePage{

	/**
	 * Initializes the super constructor of Parent class Base Page.
	 * @param driver : Driver object from the Test Class
	 * @param test : Extent Test Object from the Test Class
	 * @param appDetails : Application Details class object for initialization
	 */
	public F01_Page01(WebDriver driver,ExtentTest test,Application_Details appDetails)
	{
		super(driver,test,appDetails);
	}

	/**
	 * Function to go to Next Page in the application on the basis of Parameter.
	 * @param stNextPage : Name of the Page to go.
	 * @return : Object of the Next page that will be loaded.
	 */
	public Object goToNextPage(String stNextPage)
	{
		//perform action on Page01 to go to Page02
		if(stNextPage.equalsIgnoreCase("JavaScript"))
		{
			test.log(LogStatus.INFO, "Inside Method");

			clickElement(apDetails.getCellValue(FrmConstants.OBJECTREPO_SHEET,"F001","VALUE")); // Java Home Page
			F02_Page02 objPage2= new F02_Page02(webD,test,apDetails);
			PageFactory.initElements(webD, objPage2);
			return objPage2;
		}
		else
		{
			clickElement(apDetails.getCellValue(FrmConstants.OBJECTREPO_SHEET,"F002","VALUE")); // Default Home Page
			F03_Page03 objPage3= new F03_Page03(webD,test,apDetails);
			PageFactory.initElements(webD, objPage3);
			return objPage3;
		}

	}




}
