/**
 * Base Page Class collection of all common functions for all Pages.
 * @author ritvikkhare
 *
 */
package main.java.frm.pages.base;