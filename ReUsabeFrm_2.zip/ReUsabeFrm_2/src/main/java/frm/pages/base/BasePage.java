package main.java.frm.pages.base;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import main.java.frm.pages.common.HeaderSection;
import main.java.frm.util.Application_Details;
import main.java.frm.util.FrmConstants;

public class BasePage {

	public WebDriver webD;
	public HeaderSection header;
	public ExtentTest test;
	public static Application_Details apDetails;

	WebElement webElement;

	public BasePage(WebDriver driver,ExtentTest test,Application_Details appDetails)
	{
		this.webD=driver;
		this.test=test;
		header = PageFactory.initElements(driver,HeaderSection.class);
		apDetails = appDetails;

	}

	public void verifyTitle(String stTitle)
	{
		//code to verify title can be put here.
	}

	public void isElementPresent(String stxPath)
	{

	}

	public void clickElement(String stxPath)
	{
		webD.findElement(By.xpath(stxPath)).click();
	}

	public HeaderSection getHeaderSection()
	{
		return header;
	}

	public void takeScreenShot(){
		Date d=new Date();
		String screenshotFile=d.toString().replace(":", "_").replace(" ", "_")+".png";
		String filePath=FrmConstants.REPORTS_PATH+"screenshots//"+screenshotFile;
		// store screenshot in that file
		File scrFile = ((TakesScreenshot)webD).getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		test.log(LogStatus.INFO,test.addScreenCapture(filePath));
	}

	public void reportFailure(String failureMessage){
		test.log(LogStatus.FAIL, failureMessage);
		takeScreenShot();
		Assert.fail(failureMessage);
	}
}
