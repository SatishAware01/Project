package main.java.frm.pages;

import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import main.java.frm.pages.base.BasePage;
import main.java.frm.util.Application_Details;

public class F03_Page03 extends BasePage{
	
	public F03_Page03(WebDriver driver,ExtentTest test,Application_Details appDetails)
	{
		super(driver,test,appDetails);	
	}
	
	public void verifyDefaultPageLoad()
	{
		
	}
}
