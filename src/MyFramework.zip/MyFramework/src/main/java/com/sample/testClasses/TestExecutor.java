package com.sample.testClasses;

import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;




public class TestExecutor {

	public static void main(String args[])
	{
		TestNG runner = new TestNG();
		List<String> suiteFiles = new ArrayList<String>();
		suiteFiles.add("src/resources/TestSuite.xml");
		runner.setTestSuites(suiteFiles);
		runner.run();
	}

}
