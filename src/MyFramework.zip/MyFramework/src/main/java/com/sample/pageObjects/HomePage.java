package com.sample.pageObjects;

public class HomePage {

}
