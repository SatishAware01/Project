package com.sample.JavaPrograms;

public class InverseTriangleNumberPattern {
	public static void main(String[] args) {
        int rows = 5;
        int n=7;
        for(int i = rows; i >= 1; i--) {
            for(int j = 1; j <i; j++) {
            	System.out.print(n);
                n=n-2;
            }
            n=7;
            System.out.println();
        }



    }

}
