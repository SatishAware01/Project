package com.sample.utitlities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class TestBase {

	public static WebDriver driver = null;
	public static DesiredCapabilities cap= null;
	public static ExtentReports extent;
	public static ExtentTest test;
	public String environment;

	@BeforeSuite(alwaysRun = true)
	public void beforeSuite()
	{
		extent = ExtentManager.getInstance();
	}
	@AfterSuite(alwaysRun = true)
	public void afterSuite()
	{
		extent.flush();
		extent.close();

	}

	public void updateQC(String TestCaseName, String executionTime, String testStatus, String testSetID, String testCaseID )
	{
		System.out.println("Current Test Case : "+TestCaseName+" Status : "+testStatus);
		String testStatus_Flag=null;
		String QcUrl="http://**********/qcbin";
		String QCDomain="";
		String QCProject="";
		String QCDraftRun="N";
		String QCLoginID="";
		String QCLoginPassword="";
		String QCTestSetID=testSetID;
		String QCTestCaseID=testCaseID;
		String VBSFile="d://********//qcUpdate.vbs";
		//String testCaseStatus = testStatus;
		switch(testStatus)
		{
		case "Failed":
			testStatus_Flag="1";
			break;
		case "Passed":
			testStatus_Flag="0";
			break;
		}
		try
		{
			String[] params ={"c://windows//sysWOW64//wscript.exe",VBSFile,QCTestSetID,QCTestCaseID,testStatus_Flag,QCLoginID,QCLoginPassword,QcUrl,QCDomain,QCProject,QCDraftRun };
			Runtime.getRuntime().exec(params);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


public void setBrowserType(String browserName)
{
	if(browserName.equalsIgnoreCase("Chrome"))
	{
		System.setProperty("webdriver.chrome.driver", "C://Selenium//drivers//chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.addArguments("start-maximized");
		driver = new ChromeDriver(options);
		test.log(LogStatus.INFO, "Launching Chrome Browser.");
	}


}
public void setEnvironment(String environment)
{

}

public void closeBrowser(){
driver.close();
test.log(LogStatus.INFO, "Closing Browser Sessions.");
driver.quit();
}





}
