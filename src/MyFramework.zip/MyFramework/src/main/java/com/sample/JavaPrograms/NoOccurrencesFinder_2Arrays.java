package com.sample.JavaPrograms;

import java.util.HashMap;

public class NoOccurrencesFinder_2Arrays {
	 public static void main(String[] args) {
         int num1[]= new int[] {2,21,4,56,12,10,8,2,12,10,21};
         int num2[]=new int[]{12,8,2,10,56,12,8,8,12,4,12};

HashMap<Integer, Integer> mp= new HashMap<Integer, Integer>();
	for(int i: num1)
	{
		if(mp.containsKey(i))
			mp.put(i, mp.get(i)+1);
		else
			mp.put(i, 1);
	}

	for(int i: num2)
	{
		if(mp.containsKey(i))
			mp.put(i, mp.get(i)+1);
		else
			mp.put(i, 1);
	}

	System.out.println("Counts : "+mp);

	 }}


