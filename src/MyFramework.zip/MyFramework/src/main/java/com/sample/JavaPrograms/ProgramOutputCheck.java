package com.sample.JavaPrograms;

public class ProgramOutputCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(fun());
	}
		public static int fun(){
		return 20;
		}

}
