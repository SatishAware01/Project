package com.sample.utitlities;

import java.util.Hashtable;

public class TestUtils {

	public static boolean isSuiteRunnable(ExcelReader xls, String suiteName) {
		//log.debug("Xls name:" + xls + ", Suite name:" + suiteName);
		boolean isExecutable = false;
		for (int i = 2; i <= xls.getRowCount("Test Suite"); i++) {
			String tsid = xls.getCellData("Test Suite", "TSID", i);
			String runmode = xls.getCellData("Test Suite", "Runmode", i);
		//	log.debug(tsid + " Runmode is " + runmode);

			if (tsid.equalsIgnoreCase(suiteName)) {
				if (runmode.equalsIgnoreCase("Y")) {
					isExecutable = true;
				} else {
					isExecutable = false;
				}
			}
		}
		xls = null;
		return isExecutable;
	}



	public static boolean isTestRunnable(ExcelReader xls, String testCaseName) {
		boolean isExecutable = false;

		//log.debug("Sheet name:" + xls + ", Test case name:" + testCaseName);
		for (int i = 2; i <= xls.getRowCount("Test Cases"); i++) {
			String tcid = xls.getCellData("Test Cases", "TCID", i);
			String runmode = xls.getCellData("Test Cases", "Runmode", i);

			if (tcid.equalsIgnoreCase(testCaseName)) {
				if (runmode.equalsIgnoreCase("Y")) {
					isExecutable = true;
				} else {
					isExecutable = false;
				}
			}
		}
		xls = null;// release memory
		return isExecutable;
	}


	public static Object[][] getData(ExcelReader xls, String testCaseName, String sheetName) {

		//log.debug("Reader sheet name:" + xls + ", testcasename:" + testCaseName);
		// if the test data sheet is not present for a test case
		if (!xls.isSheetExist(testCaseName)) {
			xls = null;
			return new Object[1][0];
		}

		int rows = xls.getRowCount(testCaseName);
		int cols = xls.getColumnCount(testCaseName);

		// Retrieving data from excel
		Object[][] data = new Object[rows - 1][cols - 3];
		for (int rowNum = 2; rowNum <= rows; rowNum++) {
			for (int colNum = 0; colNum < cols - 3; colNum++) {
				data[rowNum - 2][colNum] = xls.getCellData(testCaseName, colNum, rowNum);
			}
		}
		return data;
	}

	public static String[] getDataSetRunmodes(ExcelReader xlsFile, String sheetName) {
		String[] runmodes = null;
		if (!xlsFile.isSheetExist(sheetName)) {
			xlsFile = null;
			sheetName = null;
			runmodes = new String[1];
			runmodes[0] = "Y";
			xlsFile = null;
			sheetName = null;
			return runmodes;
		}
		runmodes = new String[xlsFile.getRowCount(sheetName) - 1];
		for (int i = 2; i <= runmodes.length + 1; i++) {
			runmodes[i - 2] = xlsFile.getCellData(sheetName, "Runmode", i);
			//log.debug("Runmodes of sheet:" + xlsFile.getCellData(sheetName, "Runmode", i));
		}
		xlsFile = null;
		sheetName = null;
		return runmodes;
	}

	public static void reportDataSetResultClassLink(ExcelReader xls, String testCaseName, int rowNum, String result) {
		xls.setCellData(testCaseName, "Results", rowNum, result);
	}

	public static int getRowNum(ExcelReader xls, String id) {
		for (int i = 2; i <= xls.getRowCount("Test Cases"); i++) {
			String tcid = xls.getCellData("Test Cases", "TCID", i);
			if (tcid.equals(id)) {
				xls = null;
				return i;
			}
		}
		return -1;
	}
	public static Object[][] getData(String testName,ExcelReader xls){
        // find the row num from which test starts
        // number of cols in the test
        // number of rows
        // put the data in hastable and put hastable in array

        int testStartRowNum=0;
        // find the row num from which test starts
        for(int rNum=1;rNum<=xls.getRowCount("Test Data");rNum++){
            if(xls.getCellData("Test Data", 0, rNum).equals(testName)){
                testStartRowNum=rNum;
                break;
            }
        }
        System.out.println("Test "+ testName +" starts from "+ testStartRowNum);

        int colStartRowNum=testStartRowNum+1;
        int totalCols=0;
        while(!xls.getCellData("Test Data", totalCols, colStartRowNum).equals("")){
            totalCols++;
        }
        System.out.println("Total Cols in test "+ testName + " are "+ totalCols);

        //rows
        int dataStartRowNum=testStartRowNum+2;
        int totalRows=0;
        while(!xls.getCellData("Test Data", 0, dataStartRowNum+totalRows).equals("")){
            totalRows++;
        }
        System.out.println("Total Rows in test "+ testName + " are "+ totalRows);

        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        // extract data
        Object[][] data = new Object[totalRows][1];
        int index=0;
        Hashtable<String,String> table=null;
        for(int rNum=dataStartRowNum;rNum<(dataStartRowNum+totalRows);rNum++){
            table = new Hashtable<String,String>();
            for(int cNum=0;cNum<totalCols;cNum++){
                table.put(xls.getCellData("Test Data", cNum, colStartRowNum), xls.getCellData("Test Data", cNum, rNum));
                System.out.print(xls.getCellData("Test Data", cNum, rNum) +" -- ");
            }
            data[index][0]= table;
            index++;
            System.out.println();
        }

        System.out.println("done");

        return data;
    }
}
