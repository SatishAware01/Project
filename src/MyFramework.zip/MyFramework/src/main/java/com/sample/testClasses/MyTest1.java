package com.sample.testClasses;

import java.lang.reflect.Method;
import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.sample.utitlities.ExcelReader;
import com.sample.utitlities.TestBase;
import com.sample.utitlities.TestUtils;

public class MyTest1 extends TestBase{

	public static ExcelReader excel = new ExcelReader("C://Selenium//TestData//TestDataFile.xlsx");
	public String sheetName = "testData";

	@Parameters({"browser","environment"})
	@BeforeMethod
	public void setUp(Method method, String browser, String environment) throws Exception
	{
		if(!TestUtils.isTestRunnable(excel, this.getClass().getSimpleName()))
		{
			throw new SkipException("Skipping this Test Case.");
		}
		test = extent.startTest(this.getClass().getSimpleName() +"::"+ method.getName());
		test.assignAuthor("Satish Aware :: 9665856096");
		setBrowserType(browser);
		setEnvironment(environment);
		//deleteAllCookies();
	}

	@Test(dataProvider="getTestData")
	public void myTestOne(Hashtable<String, String> data)
	{
		System.out.println(data);

	}

	@AfterTest
	public void cleanUp(ITestResult result)
	{
		if(result.getStatus() == ITestResult.FAILURE)
		{
			System.out.println("Test Case : Failed");
			test.log(LogStatus.FAIL, "Test Case Failed.");
		}else if(result.getStatus() == ITestResult.SUCCESS)
		{
			System.out.println("Test Case : Passed");
			test.log(LogStatus.PASS, "Test Case Passed.");
		}
		closeBrowser();
		extent.endTest(test);

	}


	@DataProvider
	public Object[][] getTestData()
	{
		return TestUtils.getData(excel, this.getClass().getSimpleName(), sheetName);
	}
}
